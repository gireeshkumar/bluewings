

(function() {
    "use strict";

    const _ = require('lodash');
    const createRouter = require('@arangodb/foxx/router');
    const router = createRouter();
    module.context.use(router);

    const slides = module.context.collection('slides');


    /** Lists of all Todos
     *
     * This function simply returns the list of all todos.
     */

    router.get('/slides', function(req, res) {
        res.json(_.map(todos.toArray(), function(todo) {
            return _.omit(todo, ['_rev', '_id', '_oldRev']);
        }));
    });


}());